import processing.core.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Starburst extends PApplet {

//import javax.swing.JOptionPane;
final javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
int negvar = 15;
int posvar = 15;

static double BWBIAS = 0; //0 is no bias.  
// higher numbers for lighter, lower numbers for darker
static int CENTERBIAS = 10; //1 is no bias, higher means more towards center
// bigger numbers also take longer to make an image, but mean more toned down

static int GREYFACTOR = 0;//0 is no bias.  
// bigger numbers for greyer, up to 127 for all grey

static float RANDOMFACTOR = 1.1f;// smaller numbers are completely random (almost)
// bigger numbers more uniform layout
// 1.1 is beautiful

static final String PARAM_CHANGE_MESSAGE = 
     "Please input the initial selection value in the form" + "\n"
     + "(b/w bias, center bias, grey factor,random layout factor)";
int pixnum=0;
boolean current[][];
LinkedList<Pair> opperations = new LinkedList<Pair>();
Pair centerPair;
public void setup() {
  size(screenWidth, screenHeight);
  background(random(256), random(256), random(256));
  current = new boolean[width][height];
  centerPair = new Pair(width/2, height/2);
  opperations.addFirst(centerPair);
  falsifyCurrent();
  fillAll();
  //save("Starburst.png");
  //exit();
}

public void newImage(){
  opperations.addFirst(centerPair);
  falsifyCurrent();
  fillAll();
}

public void setParams(){
  String input = javax.swing.JOptionPane.showInputDialog(this, PARAM_CHANGE_MESSAGE);
  if(input==null) return;
  if(input.charAt(0)=='(') input = input.substring(1,input.length()-1);
  String[] params = input.split(",");
  try{
    BWBIAS = Integer.parseInt(params[0]);
    CENTERBIAS = Integer.parseInt(params[1])+1;
    GREYFACTOR = Integer.parseInt(params[2]);
    RANDOMFACTOR = Float.parseFloat(params[3]);
  }catch(Exception e){
    println(e+" in setParams()");
  }
}

public void draw(){}

public void keyPressed(){
  if(key=='s'||key=='S'||key=='p'||key=='P') setParams();
  newImage();
}

public void mousePressed(){
  //String savePath = selectOutput("select an output file");  // Opens file chooser
  fc.showSaveDialog(this);
  String savePath = fc.getSelectedFile().getAbsolutePath();
  println("file selected");
  if (savePath == null) {
    // If a file was not selected
    println("No output file was selected...");
  } else {
    // If a file was selected, save image to path
    println("saving to "+savePath);
    save(savePath);
    println("saved");
  }
}

public int getPixel(int x, int y) {
  return pixels[x+(y*width)];
}

public void setPixel(int x, int y, int c) {
  pixels[x+(y*width)]=c;
}

public void falsifyCurrent() {
  for (int i=0;i<width;i++) {
    for (int j=0;j<height;j++) {
      current[i][j]=false;
    }
  }
}

public void fillAll() {
  loadPixels();
  while (opperations.size ()>0) {
    Pair myPair=opperations.removeLast();
    int x=myPair.x, y=myPair.y;
    if (current[x][y]) continue;
    fillPixel(x, y);
    boolean iscpx = (x==centerPair.x&&y==centerPair.y);
    if (((y+1)<height)&&!current[x][y+1]) {
      if (iscpx||random(RANDOMFACTOR+1)>1) opperations.addFirst(new Pair(x, y+1));
    }
    if (((x+1)<width)&&!current[x+1][y]) {
      if (iscpx||random(RANDOMFACTOR+1)>1) opperations.addFirst(new Pair(x+1, y));
    }
    if (((y-1)>=0)&&!current[x][y-1]) {
      if (iscpx||random(RANDOMFACTOR+1)>1) opperations.addFirst(new Pair(x, y-1));
    }
    if (((x-1)>=0)&&!current[x-1][y]) {
      if (iscpx||random(RANDOMFACTOR+1)>1) opperations.addFirst(new Pair(x-1, y));
    }
  }
  finalizePixels(3);
  updatePixels();
  pixnum=0;
}

public void randomSeedPixels(){
  for(int x=0;x<width;x++){
    for(int y=0;y<height;y++){
      if(!current[x][y]&&random(1000)<2){
        for(int i=x;i<x+10&&i<width;i++){
          for(int j=y;j<y+10&&j<height;j++){
            if(!current[i][j]) fillPixel(i,j);
            //println("("+i+","+j+")");
          }
        }
      }
    }
  }
}

public void finalizePixels(int how){
  if(how==0){
    randomSeedPixels();
    for(int x=0;x<width;x++){
      for(int y=0;y<height;y++){
        if(!current[x][y]) fillPixel(x,y);
      }
    }
  }else if(how==1){
    for(int x=0;x<width;x++){
      for(int y=0;y<height;y++){
        if(!current[x][y]) fillPixel(x,y);
      }
    }
  }else if(how==2){
    for(int x=0;x<width;x++){
      for(int y=0;y<height;y++){
        if(!current[x][y]) setPixel(x,y,color(0,0,0));
      }
    }
  }else if(how==3){
    boolean[][] localcurrent = new boolean[width][height];
    opperations.addFirst(centerPair);
    while (opperations.size()>0) {
      Pair myPair=opperations.removeLast();
      int x=myPair.x, y=myPair.y;
      if(localcurrent[x][y]) continue;
      if (!current[x][y]) fillPixel(x, y);
      if (((y+1)<height)&&!localcurrent[x][y+1]) {
        opperations.addFirst(new Pair(x, y+1));
      }
      if (((x+1)<width)&&!localcurrent[x+1][y]) {
        opperations.addFirst(new Pair(x+1, y));
      }
      if (((y-1)>=0)&&!localcurrent[x][y-1]) {
        opperations.addFirst(new Pair(x, y-1));
      }
      if (((x-1)>=0)&&!localcurrent[x-1][y]) {
        opperations.addFirst(new Pair(x-1, y));
      }
      localcurrent[x][y]=true;
    }
  }
}

public void printloc(int x, int y){
  print("("+x+","+y+")");
}

public void fillPixel(int x, int y) {
  int maxr=255, minr=0, maxg=255, ming=0, maxb=255, minb=0;
  int neighborColors[]=new int[5];
  int neighborsFullYet=0;
  if (((y+1)<height)&&current[x][y+1]) {
    neighborColors[neighborsFullYet++] = getPixel(x, y+1);
  }
  if (((x+1)<width)&&current[x+1][y]) {
    neighborColors[neighborsFullYet++] = getPixel(x+1, y);
  }
  if (((y-1)>=0)&&current[x][y-1]) {
    neighborColors[neighborsFullYet++] = getPixel(x, y-1);
  }
  if (((x-1)>=0)&&current[x-1][y]) {
    neighborColors[neighborsFullYet++] = getPixel(x-1, y);
  }
  for (int i=0;i<neighborsFullYet;i++) {
    int curCol = neighborColors[i];
    int curr=(int)red(curCol), curg=(int)green(curCol), curb=(int)blue(curCol);
    if (maxr>curr) maxr=(curr+posvar);
    if (minr<curr) minr=(curr-negvar);
    if (maxg>curg) maxg=(curg+posvar);
    if (ming<curg) ming=(curg-negvar);
    if (maxb>curb) maxb=(curb+posvar);
    if (minb<curb) minb=(curb-negvar);
  }
  
  if (maxr<0) maxr=5;
  if (maxr>255) maxr=255;
  if (minr<0) minr=0;
  if (minr>255) minr=250;
  if (maxg<0) maxg=5;
  if (maxg>255) maxg=255;
  if (ming<0) ming=0;
  if (ming>255) ming=250;
  if (maxb<0) maxb=5;
  if (maxb>255) maxb=255;
  if (minb<0) minb=0;
  if (minb>255) minb=250;

  if (maxr<minr) {
    maxr=(minr+maxr)/2;
    minr=maxr;
  }
  if (maxg<ming) {
    maxg=(ming+maxg)/2;
    ming=maxg;
  }
  if (maxb<minb) {
    maxb=(minb+maxb)/2;
    minb=maxb;
  }

  int r=bound(biasedRandom(minr, maxr, CENTERBIAS, BWBIAS),GREYFACTOR,255-GREYFACTOR);
  int g=bound(biasedRandom(ming, maxg, CENTERBIAS, BWBIAS),GREYFACTOR,255-GREYFACTOR);
  int b=bound(biasedRandom(minb, maxb, CENTERBIAS, BWBIAS),GREYFACTOR,255-GREYFACTOR);
  setPixel(x, y, color(r, g, b));
  current[x][y]=true;
}

public int bound(int x, int min, int max){
  return min(max(x,min),max);
}

public int biasedRandom(int minVal, int maxVal, int biastocenter, double biasFactor) {
  //if (framenum!=0) return (int)random(maxVal-minVal+1)+minVal;
  float n = 0F;
  for(int i=0;i<biastocenter;i++){
    n+=(random((float)(maxVal-minVal+biasFactor+1))+minVal)/biastocenter;
  }
  return (int) n;
  //return (int) (random((float)(maxVal-minVal+biasFactor+1))+minVal);
}

public class Pair {
  int x=0, y=0;
  public Pair(int newX, int newY) {
    x=newX;
    y=newY;
  }
  public Pair() {
  }
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--hide-stop", "Starburst" });
  }
}
